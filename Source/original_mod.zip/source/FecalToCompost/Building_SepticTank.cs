﻿using Verse;
using DubsBadHygiene;
using System.Text;
using System;

using System.Collections.Generic;

using Verse.AI;
using RimWorld;

namespace FecalToCompost
{
	public class Building_SepticTank : SewageTreatment
	{
		public override void ExposeData()
		{
			base.ExposeData();
			Scribe_Values.Look<float>(ref this.sewageBuffer, "Sewage", 0f, false);
		}

		public override float capacity
		{
			get
			{
				return 960f;
			}
		}

		public override void SpawnSetup(Map map, bool respawningAfterLoad)
		{
			base.SpawnSetup(map, respawningAfterLoad);
		}

		public override bool working
		{
			get
			{
				//Only work if current Usage is less than capacity
				return this.sewageBuffer <= this.capacity;
			}
		}

		public override IEnumerable<FloatMenuOption> GetFloatMenuOptions(Pawn myPawn)
		{
			List<FloatMenuOption> list = new List<FloatMenuOption>();
			{
				if (!myPawn.CanReserve(this))
				{
					FloatMenuOption item = new FloatMenuOption("CannotUseReserved", null);
					return new List<FloatMenuOption>
				{
					item
				};
				}
				if (!myPawn.CanReach(this, PathEndMode.Touch, Danger.Some))
				{
					FloatMenuOption item = new FloatMenuOption("CannotUseNoPath", null);
					return new List<FloatMenuOption>
				{
					item
				};

				}

				if (sewageBuffer >= 80)
				{
					Action action = delegate
					{
						Job job1 = new Job(DefDatabase<JobDef>.GetNamed("emptySewage", true), this);
						myPawn.jobs.TryTakeOrderedJob(job1);
						myPawn.Reserve(this, job1, 1, -1, null);
					};
					list.Add(new FloatMenuOption("Empty Sewage", action));
					return list;
				}
				else 
				{
					FloatMenuOption item = new FloatMenuOption("NotEnoughSewer", null);
					return new List<FloatMenuOption>
					{
						item
					};
				}

			}
		}

		public override void Tick()
		{
			//Empty, do nothing
		}

		/*
		public override void TickRare()
		{
			base.TickRare();
			if (sewage < 100f)
			{
				sewage += 1f;
			}
		}
*/
		public float GetSewage()
		{
			return sewageBuffer;
		}

		public int EmptySewage()
		{
			//return int
			//Every
			int numberOfCompost = (int)(sewageBuffer/80);
			sewageBuffer -= numberOfCompost * 80;

			return numberOfCompost;
		}

		public override void Draw()
		{
			//Draw nothing
		}


		public override string GetInspectString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendLine("SepticTank Fill" + "  " + this.sewageBuffer);

			//Debuglines
			//stringBuilder.AppendLine("sewageBuffer : " + this.sewageBuffer);
			//stringBuilder.AppendLine("percentUsage : " + this.sewageBuffer/this.capacity);

			return stringBuilder.ToString().Trim();
		}
	}

}